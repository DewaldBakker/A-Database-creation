--creating the database
Create DataBase Community_Library
On Primary
(Name = CLPrim,
FileName = 'C:\DBD361\Milestone A\CLPrim.mdf',--this is the filepath that just needs to be added so it can work/else just change it to a diffrent path
Size = 1MB,
MaxSize= Unlimited,
FileGrowth= 1MB),

FileGroup Secondary
(Name = CLSec,
FileName = 'C:\DBD361\Milestone A\CLSec.ndf',
Size = 1MB,
MaxSize= Unlimited,
FileGrowth= 1MB)

Log On
(Name = CLLog,
FileName = 'C:\DBD361\Milestone A\CLLog.ldf',
Size = 1MB,
MaxSize= Unlimited,
FileGrowth= 1MB)

go
--Create table
Use Community_Library
Go
Create Table Members--the members that are rending books and of they are still active or not
(
MemberID INT Primary Key,
FirstName VARCHAR(50) NOT NULL, 
LastName VARCHAR(50) NOT NULL, 
Phone VARCHAR(15)  UNIQUE  NOT NULL, 
Email VARCHAR(100) UNIQUE Not NULL, 
[Address] VARCHAR(50),
MembershpDate Date,
[Status] VARCHAR(10) CHECK([Status] IN 
('Active', 'Expired'))
)
Create Table Books--this has the information of the books
(
BookID INT Primary Key,
Title VARCHAR(100) NOT NULL, 
Author VARCHAR(100)  NOT NULL, 
ISBN VARCHAR(20) UNIQUE Not NULL, 
Category VARCHAR(50) Not Null,
[Availability] Bit DEFAULT(1) Check([Availability]=1 or [Availability]=0),
YearPublished Int DEFAULT(Year(GetDate())),
CopiesAvailable Int,
Check(([Availability]=0 and CopiesAvailable=0) OR ([Availability]=1 and CopiesAvailable>0))
)

Create Table Loans--this is to see what members renrted what book
(
LoanID INT Primary Key,
MemberID INT Foreign Key References Members(MemberID),
BookID INT Foreign Key References Books(BookID),
LoanDate Date Not Null,
DueDate Date Not Null,
ReturnDate Date Null,
[Status] bit Default(1)
)

Create Table Staff--this staff members
(StaffID Int Primary Key,
FirstName VARCHAR(50) NOT NULL, 
LastName VARCHAR(50) NOT NULL, 
Role VARCHAR(30),
Email VARCHAR(100) Unique Not Null,
Phone VARCHAR(15)  UNIQUE  NOT NULL 
)

Create Table [Event]--events that are held at the libary
(EventID INT Primary Key,
EventName VARCHAR(100) NOT NULL, 
EventDate DATE NOT NULL
)

Create Table StaffEvent--what staffs work at what event
(EventID INT Foreign Key References [Event](EventID),
StaffID INT Foreign Key References Staff(StaffID)
)

go
--Create views
Create View OverdueBooks
AS
Select *
From Loans
Where ReturnDate is null;

go
Create View PopularBooks
AS
Select Books.BookID,Books.Title,Count(Loans.BookID) as [Amount Borrowed]
From Loans
Inner join Books On Books.BookID=Loans.BookID
Group by Books.BookID,Books.Title

go
Create View MembershipStatus
As
Select *
From Members


go
--Stored Procedure
Create Procedure [AddLoan]
@MemberID Int,
@BookID Int,
@LoanDate Date,
@DueDate Date
As 
Begin
Set nocount on
if Not exists(
Select 1
From Members
Where MemberID = @MemberID AND [Status] = 'Active'
)
 Begin
        RAISERROR('Invalid or inactive member.', 16, 1);
        RETURN;
End
    INSERT INTO Loans (MemberID, BookID, LoanDate, DueDate)
    VALUES (@MemberID, @BookID, @LoanDate, @DueDate);

    -- Update the book's CopiesAvailable and Availability
    UPDATE Books
    SET 
        CopiesAvailable = CopiesAvailable - 1,
        Availability = CASE 
                          WHEN CopiesAvailable - 1 = 0 THEN 0
                          ELSE 1
                      END
    WHERE BookID = @BookID;

END;

go
Create Procedure ReturnBook
    @LoanID INT,
    @ReturnDate DATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Check if the loan exists and has not already been returned
    if NOT EXISTS (
        Select 1 
		From Loans 
        WHERE LoanID = @LoanID AND ReturnDate IS NULL AND [Status] = 1
    )
    BEGIN
        RAISERROR('Loan record not found or already returned.', 16, 1);
        RETURN;
    END

    DECLARE @BookID INT;

    -- Get BookID associated with the Loan
    SELECT @BookID = BookID FROM Loans WHERE LoanID = @LoanID;

    -- Update the loan record
    UPDATE Loans
    SET 
        ReturnDate = @ReturnDate,
        [Status] = 0
    WHERE LoanID = @LoanID;

    -- Update the book: increase copies and set availability
    UPDATE Books
    SET 
        CopiesAvailable = CopiesAvailable + 1,
        Availability = 1
    WHERE BookID = @BookID;
END;

go
CREATE PROCEDURE AddMember
    @FirstName VARCHAR(50),
    @LastName VARCHAR(50),
    @Phone VARCHAR(15),
    @Email VARCHAR(100),
    @Address VARCHAR(50),
    @Status VARCHAR(10)
AS
BEGIN
    SET NOCOUNT ON;

    -- Validate status
    IF @Status NOT IN ('Active', 'Expired')
    BEGIN
        RAISERROR('Invalid status. Must be ''Active'' or ''Expired''.', 16, 1);
        RETURN;
    END

    -- Check for unique phone
    IF EXISTS (SELECT 1 FROM Members WHERE Phone = @Phone)
    BEGIN
        RAISERROR('Phone number already exists.', 16, 1);
        RETURN;
    END

    -- Check for unique email
    IF EXISTS (SELECT 1 FROM Members WHERE Email = @Email)
    BEGIN
        RAISERROR('Email already exists.', 16, 1);
        RETURN;
    END

    -- Insert new member
    INSERT INTO Members (
        FirstName, LastName, Phone, Email, [Address], MembershpDate, [Status]
    )
    VALUES (
        @FirstName, @LastName, @Phone, @Email, @Address, GETDATE(), @Status
    );
END;
go
Use Community_Library
Go
--adding data
--Books
Insert Into Books(BookID,Title,Author,ISBN,Category,[Availability],YearPublished,CopiesAvailable)
Values (1,'The Lightning Thief (Percy Jackson and the Olympians, Book 1) ','Rick Riordan','9780141','Fantasy adventure',1,2005,20)

Insert Into Books(BookID,Title,Author,ISBN,Category,[Availability],YearPublished,CopiesAvailable)
Values (2,'Dragon ball','Akira Toriyama ','9780198','Action, adventure, comedy, and fantasy',0,1985,0)

Insert Into Books(BookID,Title,Author,ISBN,Category,[Availability],YearPublished,CopiesAvailable)
Values (3,'Bleach','Tite Kubo','980456415','Shonen action',1,2001,5)
go
--Memebers
Insert into Members(MemberID,FirstName,LastName,Phone,Email,[Address],MemberShpDate,[Status])
Values(1,'Dewald','Bakker',0825292087,'Bakker@gmail.com','392 Sarel','2018-09-14','Active')
go
--Loan
Insert into Loans(LoanID,MemberID,BookID,LoanDate,DueDate)
Values(1,1,3,'2025-08-25','2025-09-25')

Insert into Loans(LoanID,MemberID,BookID,LoanDate,DueDate,ReturnDate)
Values(2,1,1,'2025-08-25','2025-09-25','2025-09-15')
go
--staff
Insert into Staff(StaffID,FirstName,LastName, Role,Email,Phone)
Values(601829,'Blaze','Inferno','Manager','BInferno@gmail.com',0987456048)

Insert into Staff(StaffID,FirstName,LastName, Role,Email,Phone)
Values(601823,'Dante','Sparda','Chasier','DMC@gmail.com',6074812345)

Insert into Staff(StaffID,FirstName,LastName, Role,Email,Phone)
Values(601827,'Max','Steel','Janitor','SteelMax@gmail.com',6078412397)
go
--Event
Insert into Event(EventID,EventName, EventDate)
Values(1,'Fun Raiser','2026-05-14')
go
--MemberEvent
Insert into StaffEvent(EventID,StaffID)
Values(1,601829)

Insert into StaffEvent(EventID,StaffID)
Values(1,601823)

Insert into StaffEvent(EventID,StaffID)
Values(1,601827)

